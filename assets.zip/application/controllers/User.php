<?php
class User extends CI_Controller{
    public function __construct(){
        parent::__construct();
    }
	public function req(){
        $this->load->view("req/head");
    }
    public function content_open(){
        $this->load->view("req/head-close");
        $this->load->view("req/body-open");
        $this->load->view("req/navbar");
        $this->load->view("req/top-navbar");
        $this->load->view("req/content-open");
    }
    public function close(){
        $this->load->view("req/content-close");
        $this->load->view("req/body-close");
        $this->load->view("req/html-close");
        $this->load->view("req/script");
    }
    public function index(){
        $field = array(
            "id_submit_user","nama_user","email_user","status_aktif_user","tgl_user_add","tgl_user_edit","tgl_user_delete"
        );
        $result = selectRow("tbl_user","",$field);
        $data["user"] = $result->result_array();
        $this->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->content_open();
        $this->load->view("master/v_user",$data);
        $this->close();
        $this->load->view("plugin/datatable/datatable-js");
    }
    public function insert(){
        $data = array(
            "nama_user" => $this->input->post("nama_user") ,
            "password_user" => md5($this->input->post("password_user")),
            "status_aktif_user" => 1,
            "tgl_user_add" => date("Y-m-d H:i:s"),
            "tgl_user_edit" => "0000-00-00 00:00:00",
            "tgl_user_delete" => "0000-00-00 00:00:00",
            "id_user_user_add" => $this->session->id_user,
            "id_user_user_edit" => 0,
            "id_user_user_delete" => 0,
            "email_user" => $this->input->post("email_user")
        );
        insertRow("tbl_user",$data);
        redirect("user");
    }
    public function update(){
        $where = array(
            "id_submit_user" => $this->input->post("id_submit_user")
        );
        $data = array(
            "nama_user" => $this->input->post("nama_user"),
            "tgl_user_edit" => date("Y-m-d H:i:s"),
            "id_user_user_edit" => $this->session->id_user,
            "email_user" => $this->input->post("email_user")
        );
        updateRow("tbl_user",$data,$where);
        redirect("user");
    }
    public function update_password(){
        $where = array(
            "id_submit_user" => $this->input->post("id_submit_user")
        );
        $data = array(
            "password_user" => md5($this->input->post("password_user")),
            "tgl_user_edit" => date("Y-m-d H:i:s"),
            "id_user_user_edit" => $this->session->id_user,
        );
        updateRow("tbl_user",$data,$where);
        redirect("user");
    }
    public function deactive($id_submit_user){
        $where = array(
            "id_submit_user" => $id_submit_user
        );
        $data = array(
            "status_aktif_user" => 0,
            "tgl_user_delete" => date("Y-m-d H:i:s"),
        );
        updateRow("tbl_user",$data,$where);
        redirect("user");
    }
    public function activate($id_submit_user){
        $where = array(
            "id_submit_user" => $id_submit_user
        );
        $data = array(
            "status_aktif_user" => 1,
            "tgl_user_delete" => date("Y-m-d H:i:s"),
        );
        updateRow("tbl_user",$data,$where);
        redirect("user");
    }
    
}
?>