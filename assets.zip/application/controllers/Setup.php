<?php
class Setup extends CI_Controller{
    public function __construct(){
        parent::__construct();
    }
    public function req(){
        $this->load->view("req/head");
    }
    public function content_open(){
        $this->load->view("req/head-close");
        $this->load->view("req/body-open");
        $this->load->view("req/navbar");
        $this->load->view("req/top-navbar");
        $this->load->view("req/content-open");
    }
    public function close(){
        $this->load->view("req/content-close");
        $this->load->view("req/body-close");
        $this->load->view("req/html-close");
        $this->load->view("req/script");
    }
    public function index(){
        $where = array(
            "status_aktif_role" => 1
        );
        $field = array(
            "phase_role","role_explanation"
        );
        $result = selectRow("tbl_phase_role",$where,$field,"","","phase_seq","ASC");
        $data["phase_role"] = $result->result_array();

        for($a = 0; $a<count($data["phase_role"]); $a++){
            $where = array(
                "status_aktif_phase" => 1,
                "phase_role" => $data["phase_role"][$a]["phase_role"]
            );
            $field = array(
                "nama_phase","status_aktif_phase","id_submit_phase","phase_seq"
            );
            $result = selectRow("tbl_phase",$where,$field,"","","phase_seq","ASC");
            $data["phase_role"][$a]["active_phase"] = $result->result_array();

            $where = array(
                "status_aktif_phase" => 0,
                "phase_role" => $data["phase_role"][$a]["phase_role"]
            );
            $field = array(
                "nama_phase","status_aktif_phase","id_submit_phase","phase_seq"
            );
            $result = selectRow("tbl_phase",$where,$field,"","","phase_seq","ASC");
            $data["phase_role"][$a]["inactive_phase"] = $result->result_array();
        }
        
        $this->req();
        $this->load->view("plugin/form/form-css");
        $this->content_open();
        $this->load->view("setup/v_setup",$data);
        $this->close();
        $this->load->view("plugin/form/form-js");
        $this->load->view("setup/v_setup_js");
    }
    public function update($id_submit_phase){
        $where = array(
            "id_submit_phase" => $id_submit_phase
        );
        $field = array(
            "status_aktif_phase","phase_role"
        );
        $result = selectRow("tbl_phase",$where,$field);
        $result_array = $result->result_array();
        $update_status =  ($result_array[0]["status_aktif_phase"]+1)%2;
        $data = array(
            "status_aktif_phase" => $update_status,
            "phase_seq" => getMaxId("tbl_phase","phase_seq",array("status_aktif_phase" => $update_status,"phase_role"=>$result_array[0]["phase_role"])),
        );
        updateRow("tbl_phase",$data,$where);
        redirect("setup");
    }
    public function insert(){
        $data = array(
            "nama_phase" => $this->input->post("nama_phase"),
            "phase_seq" => getMaxId("tbl_phase","phase_seq",array("status_aktif_phase" => 1,"phase_role"=>$this->input->post("phase_role"))),
            "phase_role" => $this->input->post("phase_role"),
            "status_aktif_phase" => 1,
            "id_user_phase_add" => $this->session->id_user,
            "tgl_user_phase_add" => date("Y-m-d H:i:s"),
        );
        insertRow("tbl_phase",$data);
        redirect("setup");  
    }
    public function modules($id_phase){
        $this->session->id_submit_phase = $id_phase;
        $field = array(
            "id_submit_phase","nama_phase","status_aktif_phase"
        );
        $result = selectRow("tbl_phase","",$field);
        $data["phase"] = $result->result_array();
        $where = array(
            "id_phase" => $id_phase
        );
        $field = array(
            "id_submit_phase_module","module_connection_name","module_connection_token","module_connection_log_id","status_aktif_module_connection","tgl_module_connection_add","tgl_module_connection_edit","module_connection_uri","id_phase"
        );
        $result = selectRow("tbl_phase_module",$where,$field);
        $data["module"] = $result->result_array();
        for($a = 0; $a<count($data["module"]); $a++){
            $where = array(
                "id_phase_module" => $data["module"][$a]["id_submit_phase_module"],
                "status_aktif_phase_module_io" => 1
            );
            $field = array(
                "id_submit_phase_module_io","access_variable_name","role_variable"
            );
            $result = selectRow("tbl_phase_module_io",$where,$field);
            $data["module"][$a]["variables"] = $result->result_array();
        }
        $data["id_phase"] = $id_phase;
        $data["nama_phase"] = get1Value("tbl_phase","nama_phase",array("id_submit_phase" => $id_phase));
        $this->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->content_open();
        $this->load->view("module/v_module",$data);
        $this->close();
        $this->load->view("plugin/datatable/datatable-js");
        $this->load->view("module/v_module_js");
    }
    public function insert_role(){
        $where = array(
            "phase_role" => $this->input->post("phase_role")
        );
        if(isExistsInTable("tbl_phase_role",$where) == 0){
            return;
        }
        else{
            $data = array(
                "phase_role" => strtoupper($this->input->post("phase_role")),
                "role_explanation" =>  $this->input->post("role_explanation"),
                "status_aktif_role" => 1,
                "tgl_phase_role_add" => date("Y-m-d H:i:s"),
                "id_user_phase_role_add" => $this->session->id_user
            );
            insertRow("tbl_phase_role",$data);
        }
        redirect("setup");
    }
    public function insert_module(){
        $id_phase = $this->input->post("id_phase");
        $data = array(
            "id_phase" => $this->input->post("id_phase"),
            "module_connection_name" => $this->input->post("module_connection_name"),
            "module_connection_token" => $this->input->post("module_connection_token"),
            "module_connection_log_id" => $this->input->post("module_connection_log_id"),
            "module_connection_uri" => $this->input->post("module_connection_uri"),
            "status_aktif_module_connection" => 1,
            "tgl_module_connection_add" => date("Y-m-d H:i:s"),
            "id_user_module_connection_add" => $this->session->id_user
        );
        $id_phase_module = insertRow("tbl_phase_module",$data);
        $checks = $this->input->post("variable_checks");
        if($checks != ""){
            foreach($checks as $a){
                $data = array(
                    "id_phase_module" => $id_phase_module,
                    "access_variable_name" => $this->input->post("variable_name".$a), 
                    "role_variable" => $this->input->post("variable_role".$a),
                    "status_aktif_phase_module_io" => 1,
                    "id_user_phase_module_io_add" => $this->session->id_user,
                    "tgl_user_phase_module_io_add" => date("Y-m-d H:i:s")
                );
                insertRow("tbl_phase_module_io",$data);
            }
        }
        $this->redirect($id_phase);
    }
    public function update_module(){
        $id_phase = $this->input->post("id_phase");
        $where = array(
            "id_submit_phase_module" => $this->input->post("id_submit_phase_module")
        );
        $data = array(
            "id_phase" => $this->input->post("id_phase"),
            "module_connection_name" => $this->input->post("module_connection_name"),
            "module_connection_token" => $this->input->post("module_connection_token"),
            "module_connection_log_id" => $this->input->post("module_connection_log_id"),
            "module_connection_uri" => $this->input->post("module_connection_uri"),
            "tgl_module_connection_edit" => date("Y-m-d H:i:s"),
            "id_user_module_connection_edit" => $this->session->id_user
        );
        updateRow("tbl_phase_module",$data,$where);

        $edit_checks = $this->input->post("edit");
        if($edit_checks != ""){
            foreach($edit_checks as $a){
                $where = array(
                    "id_submit_phase_module_io" => $a
                );
                $data = array(
                    "access_variable_name" => $this->input->post("variable_name".$a),
                    "role_variable" => $this->input->post("variable_role".$a),
                    "id_user_phase_module_io_edit" => $this->session->id_user,
                    "tgl_user_phase_module_io_edit" => date("Y-m-d H:i:s")
                );
                updateRow("tbl_phase_module_io",$data,$where);
            }
        } 
        $delete_checks = $this->input->post("delete");
        if($delete_checks != ""){
            foreach($delete_checks as $a){
                $where = array(
                    "id_submit_phase_module_io" => $a
                );
                $data = array(
                    "status_aktif_phase_module_io" => 0,
                    "id_user_phase_module_io_delete" => $this->session->id_user,
                    "tgl_user_phase_module_io_delete" => date("Y-m-d H:i:s")
                );
                updateRow("tbl_phase_module_io",$data,$where);
            }
        }
        $checks = $this->input->post("variable_checks");
        if($checks != ""){
            foreach($checks as $a){
                $data = array(
                    "id_phase_module" => $this->input->post("id_submit_phase_module"),
                    "access_variable_name" => $this->input->post("variable_name".$a), 
                    "role_variable" => $this->input->post("variable_role".$a),
                    "status_aktif_phase_module_io" => 1,
                    "id_user_phase_module_io_add" => $this->session->id_user,
                    "tgl_user_phase_module_io_add" => date("Y-m-d H:i:s")
                );
                insertRow("tbl_phase_module_io",$data);
            }
        }
        $this->redirect($id_phase);
    }
    private function redirect($id_phase){
        redirect("setup/modules/".$id_phase);
    }
    public function activate($id_submit_phase_module){
        $where = array(
            "id_submit_phase_module" => $id_submit_phase_module
        );
        $data = array(
            "status_aktif_module_connection" => 1,
            "tgl_module_connection_edit" => date("Y-m-d H:i:S"),
            "id_user_module_connection_edit" => $this->session->id_user,
        );
        updateRow("tbl_phase_module",$data,$where);
        redirect("setup/modules/".$this->session->id_submit_phase);
    }
    public function deactive($id_submit_phase_module){
        $where = array(
            "id_submit_phase_module" => $id_submit_phase_module
        );
        $data = array(
            "status_aktif_module_connection" => 0,
            "tgl_module_connection_delete" => date("Y-m-d H:i:S"),
            "id_user_module_connection_delete" => $this->session->id_user,
        );
        updateRow("tbl_phase_module",$data,$where);
        redirect("setup/modules/".$this->session->id_submit_phase);

    }
}
?>