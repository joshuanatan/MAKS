<?php
class Endpoint extends CI_Controller{
    public function __construct(){
        parent::__construct();
        $this->load->library("Curl");
    }
    public function plain_form_text(){
        $header = getallheaders();
        $string = "";
        $string .= $this->load->view("req/head","",true);

        $string .= $this->load->view("plugin/fontawesome/fontawesome-css","",true);

        $string .= $this->load->view("req/head-close","",true);
        $string .= $this->load->view("req/body-open","",true);
        $string .= $this->load->view("req/content-open","",true);
        
        $data = array(
            "redirect_url" => $header["redirect_url"],
            "update_url" => $header["update_url"],
            "update_field" => $header["update_field"],
            "id_request" => $header["id_request"]
        );
        $string .= $this->load->view("search_form/plain_text_search",$data,true);
        
        $string .= $this->load->view("req/content-close","",true);
        $string .= $this->load->view("req/body-close","",true);
        $string .= $this->load->view("req/html-close","",true);
        $string .= $this->load->view("req/script","",true);
        
        header("Content-type:application/json");
        $response = array(
            "status" => "page",
            "page" => htmlentities($string)
        );
        echo json_encode($response);
    }
    public function speech_to_text_form(){
        $header = getallheaders();
        $string = "";
        $string .= $this->load->view("req/head","",true);

        $string .= $this->load->view("plugin/fontawesome/fontawesome-css","",true);

        $string .= $this->load->view("req/head-close","",true);
        $string .= $this->load->view("req/body-open","",true);
        $string .= $this->load->view("req/content-open","",true);
        
        $data = array(
            "redirect_url" => $header["redirect_url"],
            "update_url" => $header["update_url"],
            "update_field" => $header["update_field"],
            "id_request" => $header["id_request"]
        );
        $string .= $this->load->view("search_form/speech_to_text",$data,true);
        
        $string .= $this->load->view("req/content-close","",true);
        $string .= $this->load->view("req/body-close","",true);
        $string .= $this->load->view("req/html-close","",true);
        $string .= $this->load->view("req/script","",true);
        $string .= $this->load->view("plugin/speech-to-text/speech-to-text-js","",true);
        
        header("Content-type:application/json");
        $response = array(
            "status" => "page",
            "page" => htmlentities($string)
        );
        echo json_encode($response);
    }
    public function process(){
        $search = $this->input->post("question");
        $update_field = $this->input->post("update_field");
        $body = array(
            "access_variable_name" => $update_field,
            "id_request" => $this->input->post("id_request"),
            $update_field => $search
        );
        $update_url = $this->input->post("update_url");
        $this->curl->post($update_url,array(),$body);

        $redirect_url = $this->input->post("redirect_url");
        redirect($redirect_url);
    }
}
?>