<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index(){
		$this->login();
	}
	private function req(){
		$this->load->view("req/head");
		$this->load->view("req/head-close");
		$this->load->view("req/body-open");
		$this->load->view("req/content-open");
	}
	private function close(){
		$this->load->view("req/content-close");
		$this->load->view("req/body-close");
		$this->load->view("req/html-close");
		$this->load->view("req/script");
	}
	public function login(){
		$this->req();
		$this->load->view("login/v_content_login");
		$this->close();
	}
	public function auth(){
		$where = array(
			"email_user" => $this->input->post("email_user"),
			"password_user" => md5($this->input->post("password_user")),
		);
		$field = array(
			"nama_user","id_submit_user","email_user"
		);
		$result = selectRow("tbl_user",$where,$field);
		if($result->num_rows() > 0){
			$result_array = $result->row();
			$userdata = array(
				"id_user" => $result_array->id_submit_user,
				"nama_user" => $result_array->nama_user,
				"email_user" => $result_array->email_user,
			);
			$this->session->set_userdata($userdata);
			redirect("control");
		}
	}
	public function logout(){
		$this->session->sess_destroy();
		redirect("admin");
	}
}
