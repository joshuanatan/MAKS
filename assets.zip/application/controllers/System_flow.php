<?php
class System_flow extends CI_Controller{
    public function __construct(){
        parent::__construct();
    }
    public function index(){
        $where = "";
        $field = array(
            "id_submit_phase_module","module_connection_name","module_connection_uri","module_connection_token","module_connection_log_id","nama_phase","phase_role","access_variable_name","role_variable"
        );
        $result = selectRow("v_detail_phase_simple",$where,$field,"","","","","id_submit_phase_module");
        $data["phase"] = $result->result_array();

        $where = "";
        $field = array(
            "name_module_sequence_master",
            "group_concat(module_connection_name) as module_connection_name",
            "status_aktif_module_sequence_master"
        );
        $result = selectRow("v_detail_sequence",$where,$field,"","","module_sequence","ASC","id_submit_module_sequence_master");
        $data["registered"] = $result->result_array();
        $this->page_generator->req();
        $this->load->view("plugin/datatable/datatable-css");
        $this->page_generator->head_close();
        $this->page_generator->navbar();
        $this->page_generator->content_open();
        $this->load->view("system_flow/v_system",$data);
        $this->page_generator->close();
        $this->load->view("plugin/datatable/datatable-js");
    }
    public function insert(){
        $data = array(
            "name_module_sequence_master" => $this->input->post("name_module_sequence_master"),
            "status_aktif_module_sequence_master" => 1,
            "tgl_module_sequence_master_add" => date("Y-m-d H:i:s"),
            "id_user_module_sequence_master_add" => $this->session->id_user
        );
        $id_submit_module_sequence_master = insertRow("tbl_module_sequence_master",$data);
        $checks = $this->input->post("checks");
        if($checks != ""){
            foreach($checks as $a){
                $data = array(
                    "id_module_sequence_master" => $id_submit_module_sequence_master,
                    "id_phase_module" => $a,
                    "module_sequence" => $this->input->post("sequence".$a),
                    "status_aktif_module_sequence" => 1,
                    "tgl_module_sequence_add" => date("Y-m-d H:i:S"),
                    "id_user_module_sequence_add" => $this->session->id_user,
                );
                insertRow("tbl_module_sequence",$data);
            }
        }
        redirect("system_flow");
    }
    public function update(){
        //update urutan
    }
    public function deactive($id_system){
        //matiin modulenya
    }
    public function activate($id_system){
        //nyalaiin modulenya
    }
    public function remove_module($id_system_module){
        //hilangkan module dari configurasinya
    }
}
?>