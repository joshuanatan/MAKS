    </body>
</html>
<script src="<?php echo base_url();?>assets/landing/js/vendor/jquery-2.2.4.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/vendor/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/jquery.ajaxchimp.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/owl.carousel.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/jquery.nice-select.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/jquery.counterup.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/waypoints.min.js"></script>
<script src="<?php echo base_url();?>assets/landing/js/main.js"></script>