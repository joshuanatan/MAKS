<html class="no-js">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="shortcut icon" href="img/fav.png">
        <meta name="author" content="Joshua Natan">
        <meta name="description" content="">
        <meta name="keywords" content="">
        <meta charset="UTF-8">
        <title>MAKS</title>

        <link href="https://fonts.googleapis.com/css?family=Poppins:100,300,500" rel="stylesheet">

        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/linearicons.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/owl.carousel.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/font-awesome.min.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/nice-select.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/magnific-popup.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo base_url();?>assets/landing/css/main.css">
        <style>
        @keyframes fade-in {
            from {opacity: 0;}
            to {opacity: 1;}
        }
        </style>
    </head>
    <body>