<nav class="navbar navbar-expand-lg navbar-light bg-light" style = "opacity:0;animation:fade-in 2s linear 0s;animation-fill-mode:forwards">
    <a class="navbar-brand" href="#">MAKS -</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link" href="#">Welcome</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">About</a>
            </li>
        </ul>
        <span class="navbar-text">
        Assisting you to get the information you need 
        </span>
    </div>
</nav>