
<audio src="<?php echo $audio;?>" type="audio/mpeg" id = "audioPlayer" autoplay>

