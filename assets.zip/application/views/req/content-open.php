<div class="page">
    <div class="panel">
        <div class="panel-body container-fluid">