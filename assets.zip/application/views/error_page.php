<h1 align= "center">UNFORTUNATELY, YOUR SEARCH CAN'T BE UNDERSTOOD RIGHT NOW. CONTACT APPLICATION MANAGER TO RESOLVE THE PROBLEM</h1>
<h5 align = "center">Fail Code: <?php echo $fail_code;?></h5>