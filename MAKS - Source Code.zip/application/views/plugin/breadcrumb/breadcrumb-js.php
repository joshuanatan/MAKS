<script src="<?php echo base_url();?>global/js/Plugin/asbreadcrumbs.js"></script>
<script src="<?php echo base_url();?>global/vendor/asbreadcrumbs/jquery-asBreadcrumbs.min.js"></script>